import 'package:evently/core/app_colors.dart';
import 'package:evently/core/app_provider/app_provider.dart';
import 'package:evently/widgets/select_box.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
class Onboarding1 extends StatelessWidget {
  const Onboarding1({super.key});

  @override
  Widget build(BuildContext context) {
    var provider=Provider.of<AppProvider>(context);
    ThemeData theme=Theme.of(context);
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Hero(
              tag: "logo",
                child: Image.asset("assets/images/logo/evently.png",width: 142,color: theme.primaryColor,))),
            Image.asset("assets/images/logo/being-creative.png",color:theme.primaryColorDark,),
            Text("Personalize Your Experience",style: theme.textTheme.titleLarge
            ),
            Text("Choose your preferred theme and language to get started with a comfortable, tailored experience that suits your style.",style: theme.textTheme.bodySmall),
            SizedBox(height: 18,),
            Row(
              children: [
                Text("Language",style: theme.textTheme.titleMedium),
                Spacer(),
                SelectBox(title: "English",isSelected: true,onTap: (){},),
                SizedBox(width: 8,),
                SelectBox(title: "Arabic",isSelected: false,onTap: (){},)

              ],
            ),
            SizedBox(height: 18,),
            Row(
              children: [
                Text("Theme",style: theme.textTheme.titleMedium),
                Spacer(),
                SelectBox(image: "assets/images/theme/sun.png",isSelected: provider.themeMode==ThemeMode.light?true:false,onTap: (){
                  provider.changeTheme(ThemeMode.light);

                },),
                SizedBox(width: 8,),
                SelectBox(image: "assets/images/theme/moon.png",isSelected: provider.themeMode==ThemeMode.dark?true:false,onTap: (){
                  provider.changeTheme(ThemeMode.dark);
                },)

              ],
            ),
            SizedBox(height: 24,),
            ElevatedButton(onPressed: (){},style: ElevatedButton.styleFrom(
              backgroundColor: theme.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)
              )
            ) ,child: Center(
              child: Padding(
                padding: const EdgeInsets.all(9),
                child: Text("Let’s start",style: theme.textTheme.bodyMedium),
              ),
            ))
          ],
        ),
      ),
    );
  }
}
