import 'package:evently/core/app_provider/app_provider.dart';
import 'package:evently/core/theme.dart';
import 'package:evently/modules/splash_screen/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context)=>AppProvider(),
      builder: (context,child){
        var provider=Provider.of<AppProvider>(context);
        return MaterialApp(
          themeMode: provider.themeMode,
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          home: const SplashScreen(),
        );
      },
    );
  }
}

