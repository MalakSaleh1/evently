import 'package:evently/core/app_colors.dart';
import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData lightTheme = ThemeData(
    scaffoldBackgroundColor: AppColors.lightBGColor,
    primaryColor: AppColors.lightPrimaryColor,
    dividerColor: AppColors.lightDividerColor,
    primaryColorLight: AppColors.white,
    primaryColorDark: AppColors.lightPrimaryColor,

    textTheme: const TextTheme(
      titleLarge: TextStyle(
        color: AppColors.lightTextColor,
        fontWeight: FontWeight.w600,
        fontSize: 20,
      ),

      titleMedium: TextStyle(
        color: AppColors.lightPrimaryColor,
        fontSize: 18,
        fontWeight: FontWeight.w500,
      ),

      bodyMedium: TextStyle(
        color: AppColors.white,
        fontWeight: FontWeight.w500,
        fontSize: 20,
      ),

      bodySmall: TextStyle(
        color: AppColors.lightGreyColor,
        fontSize: 16,
        fontWeight: FontWeight.w400,
      ),
    ),
  );

  static ThemeData darkTheme = ThemeData(
    scaffoldBackgroundColor: AppColors.darkBGColor,
    primaryColor: AppColors.darkPrimaryColor,
    dividerColor: AppColors.darkDividerColor,
    primaryColorLight: AppColors.darkBGColor,
    primaryColorDark: AppColors.white,

    textTheme: const TextTheme(
      titleLarge: TextStyle(
        color: AppColors.darkTextColor,
        fontWeight: FontWeight.w600,
        fontSize: 20,
      ),

      titleMedium: TextStyle(
        color: AppColors.darkPrimaryColor,
        fontSize: 18,
        fontWeight: FontWeight.w500,
      ),

      bodyMedium: TextStyle(
        color: AppColors.white,
        fontWeight: FontWeight.w500,
        fontSize: 20,
      ),

      bodySmall: TextStyle(
        color: AppColors.darkGreyColor,
        fontSize: 16,
        fontWeight: FontWeight.w400,
      ),
    ),
  );
}